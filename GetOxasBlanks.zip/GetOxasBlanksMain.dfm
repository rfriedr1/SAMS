object frmGetOxasBlanks: TfrmGetOxasBlanks
  Left = 0
  Top = 0
  ClientHeight = 96
  ClientWidth = 242
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'Tahoma'
  Font.Style = []
  OldCreateOrder = False
  OnShow = FormShow
  PixelsPerInch = 96
  TextHeight = 13
  object lblBlank: TLabel
    Left = 80
    Top = 19
    Width = 55
    Height = 19
    Caption = 'lblBlank'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -16
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
  end
  object lblOxas: TLabel
    Left = 8
    Top = 19
    Width = 52
    Height = 19
    Caption = 'lblOxas'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -16
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
  end
  object Label3: TLabel
    Left = 8
    Top = 0
    Width = 31
    Height = 13
    Caption = 'Label3'
  end
  object Button1: TButton
    Left = 48
    Top = 44
    Width = 75
    Height = 25
    Caption = 'Refresh'
    TabOrder = 0
    OnClick = Button1Click
  end
  object ADOConnKTL: TADOConnection
    LoginPrompt = False
    Left = 24
    Top = 48
  end
  object qryDb: TADOQuery
    Connection = ADOConnKTL
    Parameters = <>
    Left = 152
    Top = 40
  end
  object Timer: TTimer
    Interval = 3600000
    OnTimer = TimerTimer
    Left = 192
    Top = 8
  end
end
